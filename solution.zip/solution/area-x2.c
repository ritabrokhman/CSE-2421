#include <stdio.h>
#include <math.h>

// All user-defined headers must appear here.
double rec_calc (double left, double right);
double area_calc (double lower, double upper, int intervals);

// From here on, no headers are accepted. Only function definitions.

// Calculates the area between the left and right sides of a rectangle (each rectangle in the Riemann Sum) 
// Formula given in instructions
double rec_calc (double left, double right) {
return ((left*left + right*right) / 2.0) * (right - left);
}

// Calculates the approximate area under a curve within the range [lower, upper] by dividing it into intervals and summing up the areas of corresponding rectangles
double area_calc (double lower, double upper, int intervals) {
double segment = (upper - lower) / intervals, area = 0, left = lower;
while (left < upper) {
area += rec_calc(left, left + segment);
left += segment;
}
return area;
}


// Iteratively renews the area under the curve estimate until the difference between consecutive approximations is less than d_prec
// The resulting area is printed along with the number of intervals used and the input precision
double area_x2 (double d_prec, double d_lower, double d_upper)
{
  int i_intervals;
  double d_ret;
  double d_ret_prev;
  double d_left, d_right;

  if (d_upper <= d_lower || d_prec <= 0.0){
    d_ret_prev = -2.0;
    d_ret = -1.0;
    goto bad;
}

  for (i_intervals, i_intervals <= 1.0; fabs(d_ret_prev - d_ret) > d_prec && i_intervals > 0.0; i_intervals++) {
d_ret_prev = d_ret;
d_ret = area_calc(d_lower, d_upper, i_intervals);
}


  bad:
  // Warning to all students: DO NOT CHANGE THE LINE BELOW.
  printf ("%d %.10lf %.10lf %.10lf\n", i_intervals, d_prec, d_ret_prev, d_ret);

  return d_ret;
}

int main ()
{
  double d_lower;
  double d_upper;
  double d_prec;

  printf ("Enter lower and upper values for x, and desired precision: ");
  scanf ("%lf %lf %lf", &d_lower, &d_upper, &d_prec);
  double d_area = area_x2 (d_prec, d_lower, d_upper);
  printf ("Area under square curve between [%lf,%lf]: %lf\n", d_lower, d_upper, d_area);

  return 0;
}
