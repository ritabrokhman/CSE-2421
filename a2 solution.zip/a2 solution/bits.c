#include <stdio.h>
#include "a2.h"


// Write and use a function to count the minimum number of bits needed
// to represent an unsigned int.
unsigned int count_bits (unsigned int pat)
{
  unsigned int count = 1;
  //printf ("Input: [%d]  ----", pat);
  for (count = 1; (1<<count)<=pat; count++);
  return count;
}

// Function should return the number of 'needle' bits found
// in the parameter num.
// Argument needle must always be zero or one. 
unsigned int count_bit_type (unsigned int num, unsigned int needle)
{
  unsigned int count = 0;
  unsigned int i;
  for (i = 0; i <sizeof(int) * 8; i++)
  {
    count += (num % 2 == needle ? 1 : 0);
    num = num >> 1;
  }
  return count;
}

// Find the needle pattern in the haystack number.
// Return the number of times the needle pattern repeats.
unsigned int 
find_pattern (unsigned int haystack, unsigned int needle)
{
  unsigned int i;
  unsigned int bit_count = count_bits(needle);
  unsigned int pattern = 0;
  //printf("\n");
  for (i = 0; i <= 32 - bit_count;)
  {
    unsigned int bit_shift = 32 - i;
    unsigned int pos = ((haystack << bit_shift) >> bit_shift) >> (i - bit_count);
    //printf("(%d) needle=[%u], pos=[%u]\n", i, needle, pos);
    if (needle == pos)
    {
      //printf("* match at bit %u\n", i);  
      pattern++;
      i += bit_count;
      continue;
    }
    i++;
  }
  //printf("Input [%u,%u] ==> %u\n", haystack, needle, pattern);
  return pattern;
}

// Invert the input number nin as per the instructions of assignment 2.
unsigned int
invert_32bit (unsigned int nin)
{
  unsigned int inverted;
  inverted = (nin >> 16) | (nin << 16);
  return inverted;
}


void
translate_bits (char * filename)
{
  int num_tests;
  int ii;
  FILE * ff = NULL;
  // COMPLETE HERE: Open the file for reading.
  ff = fopen (filename, "r");
  // COMPLETE HERE: Abort the function if NULL is returned.
  if (!ff)
    return;
  // COMPLETE HERE: Read the number of test cases from the file.
  fscanf(ff, "%d", &num_tests);
  // Loop for processing. Process num_tests inputs from the text file.
  for (ii = 0; ii < num_tests; ii++)
  {
    unsigned int val;
    unsigned int needle, min_bits, min_matches;
    // COMPLETE HERE: Read four unsigned int from the file.
    fscanf (ff, "%u %u %u %u", &val, &needle, &min_bits, &min_matches);
    // Your functions should be working at this point.
    unsigned int out_val = val;
    unsigned int nb = count_bit_type (val, 1);
    unsigned int matches = find_pattern (val, needle);

    if (nb >= min_bits && matches >= min_matches)
    {
      out_val = invert_32bit (val);
    }

    // Do not change the line below.
    printf ("translate_bits(testcase=%d,haystack=%u,needle=%u,on_bits=%u,matches=%u) ==> %u\n", ii+1, val, needle, min_bits, min_matches, out_val);

    //NOTE: You can use the below functions, but only for debugging.
    //Once you are done debugging, re-comment any additional printf.

    //print_in_binary (val);
    //print_in_binary (out_val);
    //printf ("\n");
  }

  if (ff)     
    fclose (ff);
}
