#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "a3.h"
#ifndef USE_FGETS

// This function ensures that the matrix is valid and is processed correctly
int read_word_matrix(char wordmat[MAXN][MAXN], int *nrows, int *ncols)
{
scanf("%d %d", nrows, ncols);
printf("%d %d\n", *nrows, *ncols);
while (1)
{
int character;
character = getchar();
if (!isspace(character))
{
printf("Last character=%c\n", character);
ungetc(character, stdin);
break;
}
}
if (*nrows > MAXN)
return -1;
if (*ncols > MAXN)
return -1;
int i, j;
for (i = 0; i < *nrows; i++)
{
char character;
printf("Reading row %d...\n", i);
for (j = 0; j < *ncols; j++)
{
scanf("%c%c", &wordmat[i][j], &character);
}
while (1)
{
 character = getchar();
if (!isspace(character))
{
ungetc(character, stdin);
break;
}
}
}
return 0;
}
#endif

// This function loads a candidate string of the same length as needle from the matrix and returns it in the candidate argument
int extract_word(char wordmat[MAXN][MAXN], // Matrix of words.
int nrows, int ncols, // Number of rows and columns in the matrix of words.
int ii, int jj, // Coordinates of starting cell.
int di, int dj, // Direction along rows and columns. Each can be one of {-1,0,1}.
char needle[MAXN], // String to search for.
char candidate[MAXN]) // Extracted string from wordmat that starts at <row,col> and found along direction
{
int current_row = ii;
int current_col = jj;
int length = strlen(needle);
candidate[0] = 0;
int index = 0;

// Print a failure if matrix dimensions are invalid
if (current_row < 0 || current_row >= nrows || current_col < 0 || current_col >= ncols)
{
return -1;
}
for (int ii = 0; ii < length; ii++)
{
if (current_row < 0 || current_row >= nrows || current_col < 0 || current_col >= ncols)
{
candidate[0] = '\0';
return -1;
}

// Create a new null string
candidate[index++] = wordmat[current_row][current_col];
current_row += di;
current_col += dj; 
}
candidate[index] = '\0';
return 0;
}

// The function returns the number of matches of the argument needle found in the matrix of words
int search_one_word(
char wordmat[MAXN][MAXN], // Matrix of words to search in.
int nrows, int ncols, // Size of matrix of words.
char *needle) // String to search for in the matrix of words.
{
// Use previously names ints for the same application
// Direction travelled in matrix and counters
int di, dj;
int ii, jj;
int num_matches = 0;
for (ii = 0; ii < nrows; ii++)
for (jj = 0; jj < ncols; jj++)
for (di = -1; di <= 1; di += 1)
for (dj = -1; dj <= 1; dj += 1)
if (di != 0 || dj != 0)
{
char candidate[MAXN];
int out = extract_word(wordmat, nrows, ncols, ii, jj, di, dj, needle, candidate);
if (out < 0)
continue;
if (!strcmp(candidate, needle))
{
printf("--> Match at [%d,%d], direction (%d,%d)\n", ii, jj, di, dj);
num_matches++;
}
}
return num_matches;
}

// The function reads from standard input the number of words nwords to search for. After this, the function reads nwords words (each an string), searches for them in the matrix of words, and prints the number of matches (occurrences) of that word in the matrix of words.
void search_words(char wordmat[MAXN][MAXN], int nrows, int ncols)
{
int nwords;
scanf("%d", &nwords);
int i;
for (i = 0; i < nwords; i++)
{
char needle[MAXN];
scanf("%s", needle);
int matches = search_one_word(wordmat, nrows, ncols, needle);
printf("search_words(%s) = %d\n", needle, matches);
}
}
